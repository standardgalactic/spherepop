\ log.fs — append-only *executable* log (stored as Forth source lines)

40960 constant LOGCAP
create log-buf LOGCAP allot
variable log-pos
0 log-pos !

variable replaying?
0 replaying? !

: log-reset ( -- )
  0 log-pos ! ;

: log-room? ( u -- f )
  log-pos @ + LOGCAP <= ;

: log-append ( c-addr u -- )
  \ Append raw bytes into log-buf
  dup log-room? 0= if
    2drop ." [LOG FULL]" cr exit
  then
  log-buf log-pos @ + swap move
  log-pos @ + log-pos ! ;

: log-line ( c-addr u -- )
  \ Append a line plus newline, unless replaying
  replaying? @ if 2drop exit then
  \ ensure room for newline too
  dup 1+ log-room? 0= if 2drop ." [LOG FULL]" cr exit then
  log-append
  s" \n" log-append ;

: .LOG ( -- )
  cr ." --- LOG (executable) ---" cr
  log-buf log-pos @ type
  ." --- /LOG ---" cr ;

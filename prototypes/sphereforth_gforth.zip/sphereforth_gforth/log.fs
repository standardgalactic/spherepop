\ log.fs — append-only *executable* log (stored as Forth source lines)

40960 constant LOGCAP
create log-buf LOGCAP allot
variable log-pos
0 log-pos !

variable replaying?
0 replaying? !

: log-reset ( -- )
  0 log-pos ! ;

: log-room? ( u -- f )
  log-pos @ + LOGCAP <= ;

: log-append ( c-addr u -- )
  \ Append raw bytes into log-buf. `u` must survive the `move` call so
  \ it can still advance log-pos afterward; save it on the return stack.
  dup log-room? 0= if
    2drop ." [LOG FULL]" cr exit
  then
  dup >r
  log-buf log-pos @ + swap move
  r> log-pos @ + log-pos ! ;

: log-line ( c-addr u -- )
  \ Append a line plus newline, unless replaying
  replaying? @ if 2drop exit then
  \ ensure room for newline too
  dup 1+ log-room? 0= if 2drop ." [LOG FULL]" cr exit then
  log-append
  \ Plain S" never processes backslash escapes (ANS-standard), so
  \ `s" \n"` previously appended the two literal characters `\` and
  \ `n`, not a newline byte. Write the newline byte directly instead.
  10 log-buf log-pos @ + c!  1 log-pos +! ;

: .LOG ( -- )
  cr ." --- LOG (executable) ---" cr
  log-buf log-pos @ type
  ." --- /LOG ---" cr ;

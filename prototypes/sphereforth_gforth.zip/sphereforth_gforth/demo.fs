\ demo.fs — scripted example

include ops.fs
log-reset sym-reset 0 q-counter ! clear-stack

S" door-sill:pine" OPT
S" door-sill:oak"  OPT
BIND
POP
S" fastener:galv" OPT
S" fastener:ss"   OPT
COLLAPSE
.STACK
.LOG

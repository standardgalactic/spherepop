\ ops.fs — SphereForth primitives (gforth)

include log.fs
include sym.fs

\ --- stack utilities ---
: clear-stack ( -- )
  depth 0 ?do drop loop ;

\ --- logging helpers (build source lines) ---
: log-word ( c-addr u -- )  \ log "WORD"
  log-line ;

variable lo-cur  \ cursor into pad while log-opt builds its source line

: lo-emit ( char -- )        \ store one char at the cursor, advance
  lo-cur @ c!  1 lo-cur +! ;

: lo-emit-str ( c-addr u -- ) \ copy a string at the cursor, advance
  dup >r  lo-cur @ swap move  r> lo-cur +! ;

: log-opt ( c-addr u -- )   \ log: S" <name>" OPT
  \ WARNING: doesn't escape quotes in <name>
  \ Builds the line byte-by-byte in PAD: plain S" cannot embed a literal
  \ quote, and the S\" word isn't available without pulling in the rest
  \ of the standard library, so the delimiters are emitted directly.
  pad lo-cur !
  [char] S lo-emit
  [char] " lo-emit
  bl        lo-emit
  lo-emit-str
  [char] " lo-emit
  bl        lo-emit
  [char] O lo-emit
  [char] P lo-emit
  [char] T lo-emit
  pad lo-cur @ pad - log-line ;

: log-simple ( c-addr u -- ) \ log a single word line
  log-line ;

\ --- core words ---
: OPT ( c-addr u -- id )
  \ create fresh option with name, push id.
  \ NOTE: the original here used `r@ -rot set-name`, which left a
  \ stray c-addr on the stack and fed set-name (u c-addr) instead of
  \ (id c-addr u) -- set-name's own `heap-store` call would then read
  \ length as an address and crash. Saving id with `>r`/`r>` around a
  \ plain `-rot` (rather than peeking with `r@`) keeps exactly the
  \ three arguments set-name expects, in the right order.
  2dup log-opt
  fresh-id dup >r
  -rot set-name
  r> ;

: .OPT ( id -- )
  dup . ." :" space
  get-name type ;

: POP ( id -- )
  s" POP" log-simple
  drop ;

: REFUSE ( id -- )
  s" REFUSE" log-simple
  drop ;

: BIND ( a b -- a b )
  s" BIND" log-simple ;

variable q-counter
0 q-counter !

create qbuf 24 allot   \ scratch buffer for decimal digits, filled backward
variable qb-cur

: num-to-qbuf ( n -- addr u )
  \ Writes n's decimal digits into qbuf, returns addr/u. Avoids
  \ `<# #S #>`, which expects a genuine double-cell (ud) number: the
  \ original code fed it a single cell padded with a stray address
  \ (from `1 pad +`) instead of 0 as the high cell, producing garbage
  \ digits (verified: "q" followed by a raw address, not "q0").
  qbuf 24 + qb-cur !
  dup 0= if
    drop
    -1 qb-cur +!
    [char] 0 qb-cur @ c!
  else
    begin dup 0> while
      dup 10 mod [char] 0 +
      -1 qb-cur +!
      qb-cur @ c!
      10 /
    repeat
    drop
  then
  qb-cur @  qbuf 24 + qb-cur @ - ;

: next-qname ( -- c-addr u )
  \ build "qN" into PAD and return addr/u
  q-counter @ dup 1+ q-counter !
  num-to-qbuf
  pad [char] q swap c!
  2dup pad 1+ swap move
  nip 1+ pad swap ;

: COLLAPSE ( a b -- q )
  s" COLLAPSE" log-simple
  \ consume two, produce qN
  drop drop
  next-qname
  \ NOTE: the original had `2dup` here, keeping an extra (addr, len)
  \ copy of the qN name on the stack that nothing ever consumed --
  \ COLLAPSE's own signature (a b -- q) leaves only one item, so no
  \ second copy is needed (unlike OPT, which duplicates its name
  \ argument for logging *before* consuming the original for set-name).
  fresh-id dup >r
  -rot set-name
  r> ;

\ --- views ---
: .STACK ( -- )
  cr ." --- STACK (top last) ---" cr
  depth 0= if ." <empty>" cr exit then
  depth 0 do
    i pick .OPT cr
  loop
  ." --- /STACK ---" cr ;

\ --- replay ---
: REPLAY ( -- )
  \ Reconstruct frontier by re-executing the log.
  \ Disable logging during replay so we don't duplicate the log.
  clear-stack
  0 q-counter !
  sym-reset
  1 replaying? !
  log-buf log-pos @ evaluate
  0 replaying? !
  ." [replayed]" cr ;

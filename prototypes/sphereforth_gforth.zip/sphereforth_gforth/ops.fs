\ ops.fs — SphereForth primitives (gforth)

include log.fs
include sym.fs

\ --- stack utilities ---
: clear-stack ( -- )
  depth 0 ?do drop loop ;

\ --- logging helpers (build source lines) ---
: log-word ( c-addr u -- )  \ log "WORD"
  log-line ;

: log-opt ( c-addr u -- )   \ log: S" <name>" OPT
  \ WARNING: doesn't escape quotes in <name>
  pad 0!
  \ write 'S" '
  s" S\" " pad swap move
  3 constant _P0
  \ write name
  pad _P0 + 2over rot move
  \ write '" OPT'
  pad _P0 + over + s" \" OPT" rot move
  \ total len = 3 + u + 5
  _P0 + 5 + log-line
  2drop ;

: log-simple ( c-addr u -- ) \ log a single word line
  log-line ;

\ --- core words ---
: OPT ( c-addr u -- id )
  \ create fresh option with name, push id
  2dup log-opt
  fresh-id dup >r
  r@ -rot set-name
  r> ;

: .OPT ( id -- )
  dup . ." :" space
  get-name type ;

: POP ( id -- )
  s" POP" log-simple
  drop ;

: REFUSE ( id -- )
  s" REFUSE" log-simple
  drop ;

: BIND ( a b -- a b )
  s" BIND" log-simple ;

variable q-counter
0 q-counter !

: next-qname ( -- c-addr u )
  \ build "qN" into PAD and return addr/u
  pad 0!
  pad [char] q swap c!
  q-counter @ dup 1+ q-counter !
  \ append digits after 'q'
  1 pad + swap ( n ) <# #s #> \ returns addr u for digits
  \ digits live in pictured numeric buffer; copy them into PAD after q
  \ compute digits addr/u:
  2dup >r >r
  \ r: u addr
  r> r> \ restore addr u
  \ copy digits into PAD+1
  1 pad + swap move
  \ total length = 1 + u
  1 + pad swap ;

: COLLAPSE ( a b -- q )
  s" COLLAPSE" log-simple
  \ consume two, produce qN
  drop drop
  next-qname 2dup \ keep name for table
  fresh-id dup >r
  r@ -rot set-name
  r> ;

\ --- views ---
: .STACK ( -- )
  cr ." --- STACK (top last) ---" cr
  depth 0= if ." <empty>" cr exit then
  depth 0 do
    i pick .OPT cr
  loop
  ." --- /STACK ---" cr ;

\ --- replay ---
: REPLAY ( -- )
  \ Reconstruct frontier by re-executing the log.
  \ Disable logging during replay so we don't duplicate the log.
  clear-stack
  0 q-counter !
  sym-reset
  1 replaying? !
  log-buf log-pos @ evaluate
  0 replaying? !
  ." [replayed]" cr ;

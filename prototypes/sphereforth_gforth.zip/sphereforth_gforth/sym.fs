\ sym.fs — symbol table (id -> name) + fresh ids

\ We allocate ids 1..N
variable next-id
1 next-id !

\ Store names in a simple heap + table of (addr,len)
16384 constant NAMEHEAP
create name-heap NAMEHEAP allot
variable name-pos
0 name-pos !

4096 constant MAXIDS
create name-addr MAXIDS cells allot
create name-len  MAXIDS cells allot

variable hs-dest  \ scratch: destination address computed by heap-store
variable sn-id    \ scratch: id stashed by set-name while heap-store runs

: sym-reset ( -- )
  1 next-id !
  0 name-pos !
  \ Clear tables (prototype: just zero first MAXIDS; fast enough)
  MAXIDS 0 do
    0 name-addr i cells + !
    0 name-len  i cells + !
  loop ;

: heap-room? ( u -- f )
  name-pos @ + NAMEHEAP <= ;

: heap-store ( c-addr u -- c-addr' u )
  \ Copy string bytes into name-heap and return stable addr/u.
  \ `u` must stay available to advance name-pos *after* `move`, and
  \ `move`'s own three arguments must land in (src dst u) order, so
  \ the destination address is computed and stashed first.
  dup heap-room? 0= if
    2drop s" ?" exit
  then
  name-heap name-pos @ + hs-dest !
  2dup hs-dest @ swap move
  name-pos @ over + name-pos !
  nip hs-dest @ swap ;

: set-name ( id c-addr u -- )
  \ Store name ptr/len for id (id must be < MAXIDS).
  \ `id` is stashed in a variable (rather than left on the stack)
  \ because `heap-store` needs (c-addr u) exposed on top, and because
  \ it must still be available afterward to index name-addr/name-len.
  rot dup MAXIDS >= if
    drop 2drop ." [ID OUT OF RANGE]" cr exit
  then
  sn-id !
  \ heap-store gives stable addr/u
  heap-store
  dup sn-id @ cells name-len + !
  swap sn-id @ cells name-addr + ! drop ;

: get-name ( id -- c-addr u )
  dup MAXIDS >= if drop s" ?" exit then
  dup name-addr swap cells + @
  swap name-len swap cells + @ ;

: fresh-id ( -- id )
  next-id @ dup 1+ next-id ! ;

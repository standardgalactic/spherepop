\ sym.fs — symbol table (id -> name) + fresh ids

\ We allocate ids 1..N
variable next-id
1 next-id !

\ Store names in a simple heap + table of (addr,len)
16384 constant NAMEHEAP
create name-heap NAMEHEAP allot
variable name-pos
0 name-pos !

4096 constant MAXIDS
create name-addr MAXIDS cells allot
create name-len  MAXIDS cells allot

: sym-reset ( -- )
  1 next-id !
  0 name-pos !
  \ Clear tables (prototype: just zero first MAXIDS; fast enough)
  MAXIDS 0 do
    0 name-addr i cells + !
    0 name-len  i cells + !
  loop ;

: heap-room? ( u -- f )
  name-pos @ + NAMEHEAP <= ;

: heap-store ( c-addr u -- c-addr' u )
  \ Copy string bytes into name-heap and return stable addr/u
  dup heap-room? 0= if
    2drop s" ?" exit
  then
  name-heap name-pos @ + over >r  \ dst, keep u in rstack
  swap r@ move                    \ copy
  name-heap name-pos @ +          \ addr'
  r>                              \ u
  name-pos @ + name-pos ! ;

: set-name ( id c-addr u -- )
  \ Store name ptr/len for id (id must be < MAXIDS)
  rot dup MAXIDS >= if
    drop 2drop ." [ID OUT OF RANGE]" cr exit
  then
  \ heap-store gives stable addr/u
  heap-store
  \ save
  rot \ bring id back
  dup name-addr swap cells + !    \ addr
  name-len  swap cells + ! ;      \ len

: get-name ( id -- c-addr u )
  dup MAXIDS >= if drop s" ?" exit then
  dup name-addr swap cells + @
  swap name-len swap cells + @ ;

: fresh-id ( -- id )
  next-id @ dup 1+ next-id ! ;

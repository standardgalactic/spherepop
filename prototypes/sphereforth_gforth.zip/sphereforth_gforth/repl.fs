\ repl.fs — interactive loop

include ops.fs

: RESET ( -- )
  log-reset
  sym-reset
  0 q-counter !
  clear-stack
  ." [reset]" cr ;

: HELP ( -- )
  cr ." SphereForth (gforth) — commands:" cr
  ."   S\" name\" OPT      push a fresh option token (returns id)" cr
  ."   POP               drop top option (logs POP)" cr
  ."   REFUSE            drop top option (logs REFUSE)" cr
  ."   BIND              log dependency between top two (keeps them)" cr
  ."   COLLAPSE           collapse top two into qN (logs COLLAPSE)" cr
  ."   .STACK             show stack (ids + names)" cr
  ."   .LOG               show executable log" cr
  ."   REPLAY             clear + replay log (rebuild stack)" cr
  ."   RESET              clear log + symbol table + stack" cr
  ."   BYE                exit" cr ;

: run ( -- )
  HELP
  begin
    cr ." sp> " refill 0= if cr bye then
    interpret
  again ;

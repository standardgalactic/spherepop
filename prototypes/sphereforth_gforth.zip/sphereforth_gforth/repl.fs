\ repl.fs — interactive loop

include ops.fs

: qchar ( -- ) [char] " emit ;   \ prints a literal `"` (see HELP below)

: RESET ( -- )
  log-reset
  sym-reset
  0 q-counter !
  clear-stack
  ." [reset]" cr ;

: HELP ( -- )
  \ The original embedded a literal `\" ` inside a plain `."..."`
  \ string to print `S" name" OPT`. Plain `."` never processes
  \ backslash escapes (same bug as the original log-opt), so the
  \ string terminated at the first raw `"` and left `name\" OPT ...`
  \ as unparsed source, crashing with "undefined word". The quote
  \ character is now emitted separately via `qchar`.
  cr ." SphereForth (gforth) — commands:" cr
  ."   S" qchar ."  name" qchar ."  OPT      push a fresh option token (returns id)" cr
  ."   POP               drop top option (logs POP)" cr
  ."   REFUSE            drop top option (logs REFUSE)" cr
  ."   BIND              log dependency between top two (keeps them)" cr
  ."   COLLAPSE           collapse top two into qN (logs COLLAPSE)" cr
  ."   .STACK             show stack (ids + names)" cr
  ."   .LOG               show executable log" cr
  ."   REPLAY             clear + replay log (rebuild stack)" cr
  ."   RESET              clear log + symbol table + stack" cr
  ."   BYE                exit" cr ;

: run ( -- )
  HELP
  begin
    cr ." sp> " refill 0= if cr bye then
    interpret
  again ;

# SphereForth (gforth prototype)

This is a deliberately tiny, *thermodynamics-first* Spherepop prototype written for **gforth**.

## What this is
- An **append-only log** of irreversible acts.
- A stack-based “Ω-frontier” where options live *until* you spend them.
- A **replay** command that reconstructs the frontier by re-executing the log.

## What this is not (yet)
- Not SPC.
- Not a full type system.
- Not a “nice” user language.

## Run
```sh
gforth main.fs
```

## Core words (minimal)
- `S" name" OPT`  ( -- id )  
  Push a fresh option token named `name` (allocates an integer id).
- `POP`           ( id -- )  
  Irreversibly drop the top option and log it.
- `REFUSE`        ( id -- )  
  Same stack effect as POP, different accounting label.
- `BIND`          ( a b -- a b )  
  Log a dependency between the top two options (keeps them).
- `COLLAPSE`      ( a b -- q )  
  Replace top two options with a synthesized token `qN`, log the quotient.
- `.LOG`          ( -- )  
  Print the authoritative log (as executable Forth source lines).
- `REPLAY`        ( -- )  
  Clear the stack and re-run the log to reconstruct the same frontier.
- `RESET`         ( -- )  
  Clear log + symbol table (new world).

## Notes / limitations (prototype-level)
- The log is stored as Forth source lines and re-executed on `REPLAY`.
- `OPT` logging uses `S" ..."`; if your name contains a double quote `"`, replay will break.

\ main.fs — entrypoint

include repl.fs
RESET
run
